"""
File: anagram.py
Name: Max Chang
----------------------------------
This program recursively finds all the anagram(s)
for the word input by user and terminates when the
input string matches the EXIT constant defined
at line 19

If you correctly implement this program, you should see the
number of anagrams for each word listed below:
    * arm -> 3 anagrams
    * contains -> 5 anagrams
    * stop -> 6 anagrams
    * tesla -> 10 anagrams
    * spear -> 12 anagrams
"""

import time

# Constants
FILE = 'dictionary.txt'  # This is the filename of an English dictionary
EXIT = '-1'  # Controls when to stop the loop
ALPHABET = 'abcdefghijklmnopqrstuvwxyz'  # Alphabet index

# Global Variables
dictionary = [set() for i in range(26)]     # Dictionary
dict_tree = [None for i in range(26)]  # DictTree structure list for early return
find = set()


class DictTree:
    def __init__(self, value):
        next = [None for i in range(26)]
        self.value = value
        self.next = next


def main():
    # global find
    print('Reading Dictionary...')
    read_dictionary()
    print(f'Welcome to stanCode "Anagram Generator" (or {EXIT} to quit)')
    while True:
        string = input(f"Find anagrams for(or {EXIT} to quit):")
        if string == EXIT:
            break
        find.clear()
        tStart = time.time()
        string = string.lower().strip()
        find_anagrams(string)
        tEnd = time.time()
        print(f"{len(find)} anagrams: {find}")
        print(f"Use {tEnd - tStart} seconds to find.")


def read_dictionary():
    """
    Read the dictionary file into dictionary global variable
    """
    with open(FILE, 'r') as f:
        for line in f:
            queue = []
            line = line.lower().strip()
            dictionary[ALPHABET.find(line[0])].add(line)  # Add word to Dictionary
            for ch in line:  # Create Tree Structure
                index = ALPHABET.find(ch)
                if len(queue) == 0:  # First character
                    if dict_tree[index] is None:
                        dict_tree[index] = DictTree(ch)
                    queue.append(dict_tree[index])
                else:
                    if queue[-1].next[index] is None:
                        temp = DictTree(ch)
                        queue[-1].next[index] = temp
                        queue.append(temp)
                    else:
                        queue.append(queue[-1].next[index])


def find_anagrams(s):
    """
    The function to find anagrams, calls different recursion helper function
    based on different length of word
    :param s: (str) the string to find anagrams
    :return: None
    """
    print('Searching...')
    lst = []
    string = []
    lst += s
    for ch in s:
        if ch not in string:
            string.append(ch)
    for ch in string:
        lst.remove(ch)
        find_anagrams_helper(string, ch, lst, dict_tree[ALPHABET.find(ch)])
        lst.append(ch)


def find_anagrams_helper(s, chosen, lst, dict_location):
    """
    The recursion helper function for string length >12, early recursion stop by check pre_fix
    :param dict_location: the dictionary tree location for early return
    :param s: (str) filtered original string
    :param chosen: (str) the chosen string
    :param lst: (list) the remaining character
    :return: None
    """
    if len(lst) == 0:
        if chosen in dictionary[ALPHABET.find(chosen[0])] and chosen not in find:
            print('Found:', chosen)
            print('Searching...')
            find.add(chosen)
    else:
        for ch in s:
            index = ALPHABET.find(ch)
            if ch in lst and dict_location.next[index] is not None:
                lst.remove(ch)
                find_anagrams_helper(s, chosen + ch, lst, dict_location.next[index])
                lst.append(ch)


if __name__ == '__main__':
    main()
